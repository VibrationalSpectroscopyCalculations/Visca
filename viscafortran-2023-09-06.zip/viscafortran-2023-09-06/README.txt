ViscaFortran is a one file program: visca.f90

You can copy it, modify it, compile by gfortran or ifort on Linux and macos, with some effort also on Windows.

The dev folder is meant for developers; if you don't mean to add new features, it needn't be touched.

Check ou the examples folder. Make a copy of the smaller examples (actin1dir, r5neat, asg1) to learn how to run the calculations yourself.

actin2dir, asgall and khezifort are longer running examples.
They will most-likely not run them on your office laptop. Instead, on a machine with at least 64 GB of RAM and some swap space these calculations will run (at least on Linux).

If you encounter any problems: please contact us at s.j.roeters@amsterdamumc.nl / stevenroeters@gmail.com or weidner@chem.au.dk.

