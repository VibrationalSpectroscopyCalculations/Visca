#!/bin/bash

cd $(dirname "$0")
cd src
cat basics.f90 \
  para.f90 \
  tools.f90 \
  cmd_handling.f90 \
  eigen_symm.f90 \
  file_name_mod.f90 \
  linspace.f90 \
  twod_funcs.f90 \
  twodir.f90 \
  ../app/main.f90 > ../../visca.f90

# for Linux and Mac
gfortran -O0 -o ../../visca.out ../../visca.f90 -llapack -ffree-line-length-none

# since these are all small files and the .mod files are not needed here ...
rm *.mod 
cd ..

