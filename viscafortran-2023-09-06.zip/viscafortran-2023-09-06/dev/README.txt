this folder is for developers only
install fpm (Fortran Package manager, from https://fpm.fortran-lang.org/ )
then build by 
fpm build

or use the fpm scripts in some examples folders.

--
The create_single_viscafortran.sh is only needed to concatenate the various subfiles from dev 
to visca.f90
In the examples this very visca.f90 file is first always compiled (of course not necessary if you do not
change the code).
